// $(document).on('page:load', function() {
//   $('.spinner').show()
// })

$(window).load(function() {
  $('.spinner').hide()
})
;
